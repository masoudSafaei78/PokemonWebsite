<?php
use PHPUnit\Framework\TestCase;
class TestExample extends TestCase
{
public function test_example_assert_true(){

	$this->assertTrue(true);
	
}